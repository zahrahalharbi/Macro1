//
//  SplashScreen.swift
//  MoneyGrow
//
//  Created by Zahrah. on 06/06/2023.
//

import Foundation
import SwiftUI

struct SplashScreenView: View {
    @State var isActive : Bool = false
    @State private var size = 0.8
    @State private var opacity = 0.5
    @State private var presentOnbording = false
    
    var body: some View {
        VStack{
            Text("Invest your money Grow your future")
                .font(.custom("Barlow SemiBold", size: 25)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1))).multilineTextAlignment(.center)
                .padding(.top,70)
            
            ZStack {
                Image("MoneyGrow")
                    .resizable()
                    .frame(width: 150,height: 150)
                    .position(x:350,y:70)
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.6352941393852234, green: 0.843137264251709, blue: 0.6941176652908325, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.27450981736183167, green: 0.364705890417099, blue: 0.8980392217636108, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.04246575376670733, y: 0.9999998511313493),
                        endPoint: UnitPoint(x: 0.9999999964329068, y: 0.9999998511313493)))
                    .frame(width: 700, height: 700)
                    .position(x:100,y:560)
                    .shadow(radius: 10)
                    .shadow(radius: 10)
                VStack{  Circle()
                        .fill(Color(#colorLiteral(red: 0.6352941393852234, green: 0.843137264251709, blue: 0.6941176652908325, alpha: 1)))
                        .frame(width: 450, height: 450)
                        .position(x:-100,y:350)
                        .shadow(radius: 10)
                    .shadow(radius: 10)}
                
            }
            .onAppear {
                withAnimation(.easeIn(duration: 2.0)) {
                    self.size = 0.5
                    self.opacity = 1.00
                }
                Circle()
                    .strokeBorder(Color.white)
                    .frame(width: 600, height: 600)
                    .position(x:100,y:240)
                    .shadow(radius: 10)
            }
            .fullScreenCover(isPresented: $presentOnbording) {
                ContentView()
            }
            .scaleEffect(size)
            .opacity(opacity)
            
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
                    withAnimation {
                        self.isActive = true
                        presentOnbording.toggle()
                    }
                }
            }
        }
    }
struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
        
    }
}
