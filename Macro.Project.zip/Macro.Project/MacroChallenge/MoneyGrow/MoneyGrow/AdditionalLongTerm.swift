//
//  Recommendation2.swift
//  MoneyGrow
//
//  Created by Zahrah. on 05/06/2023.
//

import UIKit
import Foundation
import SwiftUI

struct AdditionalLongTerm: View {
    @State var Stocks = false
    @State var funds = false
    @State var State = false
    var body: some View {
        ZStack{
      
                NavigationView {
                    VStack{
                        Text("Suggestions").font(.custom("Barlow SemiBold", size: 37)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1))).multilineTextAlignment(.center)
                            .padding(.bottom,40)
                        Text("The right type of investment for you based on your answers  ").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                            .padding(.top,-30)
                            .padding(.bottom,20)
                            .padding(.leading,0)
                        
                        Form {
                            
                            Section{
                                DisclosureGroup(
                                    
                                    
                                    isExpanded: $Stocks ,
                                    content: {  Text("Stocks are one of the most popular investment assets that can generate high returns in the long run, and allow investors to benefit from the growth of the economy and companies.").font(.custom("Barlow Medium", size: 14)
                                    ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                        
                                    },
                                    label: {
                                        Text("Stocks")
                                            .fontWeight(.bold)
                                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                            .padding(.leading,120)
                                        
                                    })
                                
                            }
                            .listRowBackground(Color.white)
                            
                            
                            Section{
                                DisclosureGroup(
                                    
                                    
                                    
                                    isExpanded: $State ,
                                    content: {  Text("Real estate is considered one of the fixed and reliable assets in long-term investment, and it allows investors to obtain stable returns from rents and a large profit from selling the property in the future."
                                    ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                        
                                    },
                                    label: {
                                        Text("Real State")
                                            .fontWeight(.bold)
                                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                            .padding(.leading,110)
                                        
                                        
                                    })}
                            
                            Section{   DisclosureGroup(
                                
                                
                                
                                isExpanded: $funds ,
                                content: {  Text("It allows investors to invest in a variety of investment assets without the need to purchase each of them separately, and it allows investors to access a diversified portfolio of assets that can reduce the risks associated with market fluctuations."
                                ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                    
                                },
                                label: {
                                    Text("Investment Funds")
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                        .padding(.leading,90)
                                    
                                    
                                })}
                            
                        }
                        .shadow(radius:5)
                        .foregroundColor(.brown)
                        
                        .tint(Color(red: 0.166, green: 0.265, blue: 0.527))
                        .background(Color.white)
                        
                        .scrollContentBackground(.hidden)
                        
                    }
                    
                }
                
                .ignoresSafeArea(.all)
                .padding(.top,30)
//            Circle()
//                .fill(LinearGradient(
//                    gradient: Gradient(stops: [
//                .init(color: Color(#colorLiteral(red: 0.6352941393852234, green: 0.843137264251709, blue: 0.6941176652908325, alpha: 1)), location: 0),
//                .init(color: Color(#colorLiteral(red: 0.27450981736183167, green: 0.364705890417099, blue: 0.8980392217636108, alpha: 1)), location: 1)]),
//                    startPoint: UnitPoint(x: 0.04246575376670733, y: 0.9999998511313493),
//                    endPoint: UnitPoint(x: 0.9999999964329068, y: 0.9999998511313493)))
//                .shadow(radius: 10)
//               
//                .frame(width: 200, height: 200)
//                .position(x:0,y:530)
            Circle()
                .strokeBorder(Color(red: 0.6705882352941176, green: 0.7333333333333333, blue: 1.0), lineWidth: 0.5)
                .frame(width: 300, height: 300)
                .position(x:400,y:600)
                .shadow(radius: 10)
            
            }
        
        }}
struct AdditionalLongTerm_Previews: PreviewProvider {
    static var previews: some View {
        AdditionalLongTerm()
    }
}
