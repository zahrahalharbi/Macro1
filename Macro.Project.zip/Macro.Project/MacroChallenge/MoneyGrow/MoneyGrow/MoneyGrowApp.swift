//
//  MoneyGrowApp.swift
//  MoneyGrow
//
//  Created by sara ayed albogami on 08/11/1444 AH.
//

import SwiftUI

@main
struct MoneyGrowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
