//
//  TabBarItem.swift
//  MoneyGrow
//
//  Created by sara ayed albogami on 09/11/1444 AH.
//


//
//import Foundation
//
//enum TabBarItem: CaseIterable {
//    case planPage
//    case chatBot
//    
//   
//    
//    var title: String {
//        switch self {
//        case .planPage:   return NSLocalizedString("Plans", comment: "")
//        case .chatBot:     return NSLocalizedString("ChatBot", comment: "")
//      
//        }
//    }
//    
//    var imageName: String {
//        switch self {
//        case .planPage:   return "dollarsign.square"
//            //            Image(systemName:"check-list")
//        case .chatBot:     return "text.bubble"
//     
// 
//        }
//    }
//}
