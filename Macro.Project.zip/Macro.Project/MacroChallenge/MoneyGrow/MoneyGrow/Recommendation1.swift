//
//  Recommendation1.swift
//  MoneyGrow
//
//  Created by Zahrah. on 05/06/2023.
//

import Foundation
import SwiftUI

struct Recommendation1: View {
   @State var shown = 4
    @StateObject var RecList = recommendationlist()
    
      @Binding var First: String

    var body: some View {
        
        NavigationView {
            
            ZStack{
                
                VStack{
                    
                    Text("Suggestions").font(.custom("Barlow SemiBold", size: 37)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1))).multilineTextAlignment(.center)
                        .padding(.bottom,40)
                    Text("The right type of investment for you based on your answers").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                        .padding(.top,-30)
                        .padding(.bottom,20)
                    
                    ZStack{
                        HStack{
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                                .frame(width: 356, height: 120)
                                .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.25)), radius:2, x:0, y:2)
//                                .padding(.top,100)
                            Text("bbbbb").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                
                        }
                        .padding(.bottom,400)
                        Text("Stocks")
                            .fontWeight(.bold)
                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                            .padding(.top,-250.0)
                            .padding(.trailing,25)
                        Text("Stocks are one of the most popular investment assets that can generate high returns in the long run, and allow investors to benefit from the growth of the economy and companies.").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                            
                            .padding(.bottom,370)
                            .padding(.horizontal,14)
    
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                        .frame(width: 356, height: 160)
                        .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.25)), radius:2, x:0, y:2)
                        .padding(.top,230)
                        
                                             
                            Text("Investment Funds")
                            .fontWeight(.bold)
                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                            .padding(.top,110)
                        Text("It allows investors to invest in a variety of investment assets without the need to purchase each of them separately, and it allows investors to access a diversified portfolio of assets that can reduce the risks associated with market fluctuations.").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                            
                            .padding(.top,240)
                            .padding(.horizontal,14)
                        
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                        .frame(width: 356, height: 120)
                        .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.25)), radius:2, x:0, y:2)
                        .padding(.top,-110)
  
                        Text("Real estate")
                            .fontWeight(.bold)
                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                            .padding(.top,-110)
                            .padding(.trailing,20)
                    
                        Text("Real estate is considered one of the fixed and reliable assets in long-term investment, and it allows investors to obtain stable returns from rents and a large profit from selling the property in the future.").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                            
                            .padding(.bottom,95)
                            .padding(.horizontal,14)
                    
                    }
//                    .padding()
                    
                    Spacer()
                }
            }
     
        
            .ignoresSafeArea(.all)
            .padding(.all)
            .padding(.top,20)
         
        
        }
    }
}

struct Recommendation1_Previews: PreviewProvider {
    static var previews: some View {
        Recommendation1(First: .constant(""))
    }
}
