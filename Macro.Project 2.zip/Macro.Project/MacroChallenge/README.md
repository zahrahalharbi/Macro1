# MacroChallenge
## GrowthMoney App
#### An application that provides plan for different investors with lowest risk possible, and calculates the savings with the range of years depending on investor choice.

## Features :
#### -Provide an investment plan so that the user can achieve targeted goals.
#### -Calculation of savings amount after range of year depend on user choice
#### -Localization (Arabic, and English)
<img width="166" alt="Screenshot 2023-05-31 at 8 59 38 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/f7a0fba7-5e63-4c02-bd07-a9c5b5627442">
<img width="154" alt="Screenshot 2023-05-31 at 8 59 48 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/adc0434e-f585-4884-8622-e3b715ca7754">
<img width="154" alt="Screenshot 2023-05-31 at 8 59 56 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/9bcfd15d-c41d-4f0a-94be-a387a388952a">
<img width="156" alt="Screenshot 2023-05-31 at 9 00 13 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/deda0e25-fc28-4d4d-9e10-6d720ed8f247"><img width="154" alt="Screenshot 2023-05-31 at 9 00 21 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/38f6233e-d6b3-4ffc-bd22-a193bd35b91a">
<img width="155" alt="Screenshot 2023-05-31 at 9 00 30 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/683f0bae-ec13-4363-9514-d968b4a41ae2">
<img width="153" alt="Screenshot 2023-05-31 at 9 00 05 AM" src="https://github.com/zahrahalharbi/MacroChallenge/assets/116794510/85f9c221-1045-44bb-86aa-20382267efd6">

