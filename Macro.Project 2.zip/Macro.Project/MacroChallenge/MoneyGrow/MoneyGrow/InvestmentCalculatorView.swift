//
//  InvestmentCalculatorView.swift
//  MoneyGrow
//
//  Created by Zahrah. on 08/06/2023.
//

import SwiftUI
import SwiftUICharts
import Charts

struct InvestmentCalculatorView: View {
    @State private var investmentReturns: Double = 0.0
    @State private var investmentAmount: Double = 0.0
    @State private var numYears: Int = 0
    @State var isPresented1 = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        
        VStack{
            ZStack{
                CloseButton(action: { dismiss() })
                    .padding(.top,-50)
            }
            Text("Investment calculator")
                .font(Font.custom("Barlow-Bold", size: 25))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.36, green: 0.46, blue: 0.91))
                .frame(minWidth: 262.00, minHeight: 44.00, alignment: .top)
                .padding(.top,-5)
            
            Text("Return rate (%)")
                .font(Font.custom("Barlow-Medium", size: 20))
                .padding(.trailing,220)
                .foregroundColor(Color(red: 0.17, green: 0.27, blue: 0.54))
                .frame(minWidth: 128.00, minHeight: 28.00, alignment: .topTrailing)
                
            Section(header: Text("")) {
                TextField("Return rate (%)", value: $investmentReturns, formatter: NumberFormatter())
                    .keyboardType(.decimalPad)
                    .padding(.leading,20)
                
                Text("Investment Amount ")
                    .font(Font.custom("Barlow-Medium", size: 20))
                    .padding(.trailing,200)
                    .foregroundColor(Color(red: 0.17, green: 0.27, blue: 0.54))
                    .frame(minWidth: 178.00, minHeight: 28.00, alignment: .topTrailing)
                    .padding(.leading,20)
                
                TextField("Investment Amount", value: $investmentAmount, formatter: NumberFormatter())
                    .keyboardType(.decimalPad)
                    .padding(.leading,20)
                
                Text("Numbers of years  ")
                    .font(Font.custom("Barlow-Medium", size: 20))
                    .padding(.trailing,195)
                    .foregroundColor(Color(red: 0.17, green: 0.27, blue: 0.54))
                    .frame(minWidth: 195.00, minHeight: 28.00, alignment: .topTrailing)
                    .padding(.leading,10)
                Stepper(" \(numYears)", value: $numYears, in: 0...30)
                    .padding(.horizontal,18)
                    
            }
            
            
            if !isPresented1{
                Button {
                    // Calculate the investment growth
                    let investmentGrowth = calculateInvestmentGrowth()
                    // If the investment growth is not empty, show the chart
                    if !investmentGrowth.isEmpty {
                        isPresented1.toggle()
                    }
                    
                } label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 13)
                            .fill(LinearGradient(gradient: Gradient(stops: [.init(color: Color(red: 0.64, green: 0.84, blue: 0.69), location: 0.00), .init(color: Color(red: 0.27, green: 0.36, blue: 0.90), location: 1.00)]), startPoint: .leading, endPoint: .trailing))
                            .frame(width: 273.00, height: 62.00)
                        Text("Calculate")
                            .font(Font.custom("Barlow-Medium", size: 24))
                            .multilineTextAlignment(.center)
                            .foregroundColor(Color.white)
                            .frame(minWidth: 124.00, minHeight: 37.00, alignment: .top)
                        
                    }  .padding(.top,100)
                }
                
            }
            // If the `isPresented1` binding is true, show the chart
            if isPresented1 {
                Section(header: Text("")) {
                    LineView(data: calculateInvestmentGrowth(), title: "Investment Growth", legend: "")
                        .foregroundColor(Color("ButtonColor2"))
                    // .lineMark(x: .value("Year", numYears), y: .value("Investment Growth", investmentAmount))
                    //
                        .frame(width: 300, height: 300)
                }
            }
        }
        
    }
    private func calculateInvestmentGrowth() -> [Double] {
        var growth = investmentAmount
        var investmentGrowth: [Double] = []
        
        for _ in 1...30 {
            growth += growth * investmentReturns / 100
            investmentGrowth.append(growth)
        }
        return investmentGrowth
    }
}

struct InvestmentCalculatorView_Previews: PreviewProvider {
    static var previews: some View {
        InvestmentCalculatorView()
    }
}
