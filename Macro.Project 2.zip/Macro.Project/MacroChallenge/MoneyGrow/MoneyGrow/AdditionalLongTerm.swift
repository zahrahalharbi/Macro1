//
//  Recommendation2.swift
//  MoneyGrow
//
//  Created by Zahrah. on 05/06/2023.
//


import UIKit
import Foundation
import SwiftUI

struct AdditionalLongTerm: View {
    @State var Stocks = false
    @State var funds = false
    @State var State = false
    @State var isExpanded = false
    @Environment(\.dismiss) var dismiss
    var body: some View {
        ZStack{
            
                NavigationView {
                    
                    VStack{
                        CloseButton(action: { dismiss() })
                        
                        Text("Suggestions").font(.custom("Barlow SemiBold", size: 37)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1))).multilineTextAlignment(.center)
                            .padding(.bottom,40)
                            .padding()
                        Text("The right type of investment for you\n based on your answers  ").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                            .padding(.top,-50)
                            .padding(.bottom,20)
                            .padding(.leading)
                        
                       
                        Form {
                            
                            Section{
                                
                                DisclosureGroup(
                                    
                                    
                                    isExpanded: $Stocks ,
                                    content: {  Text("Stocks are one of the most popular investment assets that can generate high returns in the long run, and allow investors to benefit from the growth of the economy and companies.").font(.custom("Barlow Medium", size: 14)
                                    ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                        
                                    },
                                    label: {
                                        Text("Stocks")
                                            .frame(width: 328, height: 24)
                                            .fontWeight(.bold)
                                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                            .padding()
                                        Image(systemName: self.isExpanded ? "chevron.up" : "chevron.down")
                                            .fontWeight(.medium)
                                            .foregroundColor(.gray)
                                            .padding(.leading,-50)
                                        
                                    })
                                
                            }
                            .listRowBackground(Color.white)
                            
                            
                            Section{
                                DisclosureGroup(
                                    
                                    
                                    
                                    isExpanded: $State ,
                                    content: {  Text("Real estate is considered one of the fixed and reliable assets in long-term investment, and it allows investors to obtain stable returns from rents and a large profit from selling the property in the future."
                                    ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                        
                                    },
                                    label: {
                                        Text("Real State")
                                            .frame(width: 328, height: 24)
                                            .fontWeight(.bold)
                                            .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                            .padding()
                                        Image(systemName: self.isExpanded ? "chevron.up" : "chevron.down")
                                            .fontWeight(.medium)
                                            .foregroundColor(.gray)
                                            .padding(.leading,-50)
                                        
                                        
                                    })}
                            
                            Section{
                                DisclosureGroup(
                                
                                isExpanded: $funds ,
                                content: {  Text("It allows investors to invest in a variety of investment assets without the need to purchase each of them separately, and it allows investors to access a diversified portfolio of assets that can reduce the risks associated with market fluctuations."
                                ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                    
                                },
                                label: {
                                    Text("Investment Funds")
                                        .frame(width: 328, height: 24)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                        .padding()
                                    Image(systemName: self.isExpanded ? "chevron.up" : "chevron.down")
                                        .fontWeight(.medium)
                                        .foregroundColor(.gray)
                                        .padding(.leading,-50)
                                    
                                    
                                })
                                
                            }
                            
                        }
                        
                        .shadow(radius:5)
                        .tint(Color(red: 0.166, green: 0.265, blue: 0.527))
                        .background(Color.white)
                        .scrollContentBackground(.hidden)
                        .padding(.top,-30)
                        
                }
            }
                .ignoresSafeArea(.all)
                .padding(.top,30)
        }
    }
}
struct AdditionalLongTerm_Previews: PreviewProvider {
    static var previews: some View {
        AdditionalLongTerm()
    }
}
