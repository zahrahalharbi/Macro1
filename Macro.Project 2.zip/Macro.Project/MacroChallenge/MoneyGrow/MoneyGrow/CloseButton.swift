//
//  CloseButton.swift
//  MoneyGrow
//
//  Created by Zahrah. on 08/06/2023.
//

import Foundation

import SwiftUI

struct CloseButton: View {
    let action: () -> Void
    
    var body: some View {
        
        Button {
            action()
        } label: {
            Image(systemName: "xmark")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.leading, 16)
        .foregroundColor(.black)
    }
}

struct CloseButton_Previews: PreviewProvider {
    static var previews: some View {
        CloseButton(action: { })
            .previewLayout(.sizeThatFits)
    }
}
