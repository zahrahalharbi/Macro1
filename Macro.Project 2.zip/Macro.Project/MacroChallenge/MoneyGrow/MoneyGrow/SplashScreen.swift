//
//  SplashScreen.swift
//  MoneyGrow
//
//  Created by Zahrah. on 06/06/2023.
//
import Foundation
import SwiftUI

struct SplashScreenView: View {

    @State private var isActive = false
     @State private var size = 0.8
     @State private var opacity = 0.5
     @State private var presentOnbording = false
     @State private var size1 = 0.6
     @State private var opacity1 = 1.0
     @State  var offset: Int
    
var body: some View {
    NavigationView{
        VStack{
            
            HStack{
                Text("Invest your money\nGrow your future").font(.custom("Barlow Bold", size: 30)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1)))
                    .fontWeight(.bold).multilineTextAlignment(.center)
                    .padding(.top,70)
            }
            .scaleEffect(size1)
            .opacity(opacity1)
            .onAppear {
                withAnimation(.easeIn(duration: 2.0)) {
                    self.size1 = 1.0
                    self.opacity1 = 0.9
                }
            }
            
            
            
            ZStack {
                
                
                Ellipse()
                    .fill(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.6352941393852234, green: 0.843137264251709, blue: 0.6980392336845398, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.35686275362968445, green: 0.4627451002597809, blue: 0.9098039269447327, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.896866831241945, y: 0.589474059991133),
                        endPoint: UnitPoint(x: 0.03002611956187179, y: 0.6447371887349291)))
                    .frame(width: 650, height: 650)
            
                    .rotationEffect(.degrees(-68.43))
                    .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.25)), radius:4, x:0, y:4)
                    .position(x:10,y:350)
                    .shadow(radius: 10)
                
                
                //                Image("MoneyGrow")
                //                    .resizable()
                //                    .frame(width: 250,height: 250)
                //                    .position(x:40,y:350)
                
                Ellipse()
                    .strokeBorder(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), lineWidth: 1)
                    .frame(width: 550, height: 550)
                    .position(x:10,y:350)
                
                Ellipse()
                .strokeBorder(Color(#colorLiteral(red: 0.6708333492279053, green: 0.7338653802871704, blue: 1, alpha: 1)), lineWidth:5)
                .frame(width: 500, height: 500)
                .position(x:490 , y:870)

                            Ellipse()
                                .strokeBorder(Color(#colorLiteral(red: 0.6392157077789307, green: 0.8470588326454163, blue: 0.7019608020782471, alpha: 1)), lineWidth: 5)
                            .frame(width: 430, height: 450)
                            .position(x:530 , y:910)
                Ellipse()
                
                    .fill(Color(#colorLiteral(red: 0.35686275362968445, green: 0.4627451002597809, blue: 0.9098039269447327, alpha: 1)))
                
                    .frame(width: 400, height: 400)
                    .rotationEffect(.degrees(150.42))
                    .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.25)), radius:4, x:0, y:4)
                    .position(x:-230 , y:90)
                Image("logo1")
                    .resizable()
                    .frame(width: 250,height: 250)
                    .position(x:40,y:350)
                
                
            }
            .scaleEffect(size)
            .opacity(opacity)
            .onAppear {
                withAnimation(.easeIn(duration: 2.0)) {
                    self.size = 0.5
                    self.opacity = 1.00
                }
            }
            .fullScreenCover(isPresented: $presentOnbording) {
                ContentView()
            }
           
            
        }

        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
                withAnimation {
                    self.isActive = true
                    presentOnbording.toggle()
                }
            }
        }

    }
    }
}
struct SplashScreenView_Previews: PreviewProvider {
        static var previews: some View {
                 SplashScreenView(offset: 1)

     }
}
