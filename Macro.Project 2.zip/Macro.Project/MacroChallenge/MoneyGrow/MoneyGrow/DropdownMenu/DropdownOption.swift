//
//  DropdownOption.swift
//  MoneyGrow
//
//  Created by sara ayed albogami on 08/11/1444 AH.
//
import Foundation


struct DropdownMenuOption1: Identifiable, Hashable {
    let id = UUID().uuidString
    let option: String
    let tag : Int
    let Subtag : Int
}

extension DropdownMenuOption1 {
    static let testSingleChoice: DropdownMenuOption1 = DropdownMenuOption1(option: "Additional income and capital increase ",tag:1,Subtag:1)
    static let testAllChoices: [DropdownMenuOption1] = [
        DropdownMenuOption1(option: NSLocalizedString("Additional income and capital increase ",comment: ""),tag: 1 , Subtag :1),
        DropdownMenuOption1(option: NSLocalizedString("Achieving certain goals",comment: ""),tag: 2, Subtag:2),
       
    ]
    
}


extension DropdownMenuOption1 {
    static let testSingleChoice2: DropdownMenuOption1 = DropdownMenuOption1(option: "longterm",tag: 3 , Subtag :3)
    static let testAllChoices2: [DropdownMenuOption1] = [
        DropdownMenuOption1(option: NSLocalizedString("Long Term",comment: ""),tag: 3, Subtag:3),
        DropdownMenuOption1(option: NSLocalizedString("Short Term",comment: ""),tag: 4, Subtag :4)
    ]
    
}
