//
//  AcheivingLongTerm.swift
//  MoneyGrow
//
//  Created by Zahrah. on 06/06/2023.
//

import Foundation

import UIKit
import Foundation
import SwiftUI

struct AcheivingLongTerm: View {
    @State var Islamicsukuk = false
    @State var RealState = false
    @State var Governmentbonds = false
    @State var isOptionsPresented = false
    @Environment(\.dismiss) var dismiss
    var body: some View {
        ZStack{
            NavigationView {
                VStack{
                    CloseButton(action: { dismiss() })
                    Text("Suggestions").font(.custom("Barlow SemiBold", size: 37)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1))).multilineTextAlignment(.center)
                        .padding(.bottom,40)
                        .padding()
                    Text("The right type of investment for you\n based on your answers  ").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                        .padding(.top,-50)
                        .padding(.bottom,20)
                        .padding(.leading,0)
                    
                    ZStack{  Form {
                        Section{
                            DisclosureGroup(
                                
                                
                                isExpanded: $Islamicsukuk ,
                                content: {  Text("Islamic sukuk can be invested in the long term to achieve specific goals, as Islamic sukuk is an increasingly popular investment tool in the world and provides an opportunity for investors to achieve desired returns while at the same time adhering to Islamic principles.").font(.custom("Barlow Medium", size: 14)
                                ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                    
                                },
                                label: {
                                    Text("Stocks")
                                        .frame(width: 328, height: 24)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                        .padding()
                                    Image(systemName: self.isOptionsPresented ? "chevron.up" : "chevron.down")
                                        .fontWeight(.medium)
                                        .foregroundColor(.gray)
                                        .padding(.leading,-40)
                                    
                                })}
                        
                        Section{
                            DisclosureGroup(
                                
                                
                                
                                isExpanded: $Governmentbonds,
                                content: {  Text("Government bonds can be invested in the near term to increase income, as government bonds provide fixed and guaranteed returns and are considered one of the safest financial instruments.Government bonds are considered a loan that the investor gives to the government"
                                ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                    
                                },
                                label: {
                                    Text("Government Bonds")
                                        .frame(width: 328, height: 24)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                        .padding()
                                    Image(systemName: self.isOptionsPresented ? "chevron.up" : "chevron.down")
                                        .fontWeight(.medium)
                                        .foregroundColor(.gray)
                                        .padding(.leading,-40)
                                    
                                    
                                })}
                        
                        Section{   DisclosureGroup(
                            
                            
                            
                            isExpanded: $RealState ,
                            content: {  Text("Real estate is considered one of the fixed and reliable assets in long-term investment, and it allows investors to obtain stable returns from rents and a large profit from selling the property in the future."
                            ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                
                            },
                            label: {
                                Text("Real State")
                                    .frame(width: 328, height: 24)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                    .padding()
                                Image(systemName: self.isOptionsPresented ? "chevron.up" : "chevron.down")
                                    .fontWeight(.medium)
                                    .foregroundColor(.gray)
                                    .padding(.leading,-40)
                                
                                
                            })}
                        
                    }}
                    .shadow(radius:5)
                    .foregroundColor(.brown)
                    
                    .tint(Color(red: 0.166, green: 0.265, blue: 0.527))
                    .background(Color.white)
                    .padding(.top,-30)
                    .scrollContentBackground(.hidden)
                }
               
                
            }
            .ignoresSafeArea(.all)
            .padding(.top,30)
   
         
        }
    }}
struct AcheivingLongTerm_Previews: PreviewProvider {
    static var previews: some View {
        AcheivingLongTerm()
    }
}

