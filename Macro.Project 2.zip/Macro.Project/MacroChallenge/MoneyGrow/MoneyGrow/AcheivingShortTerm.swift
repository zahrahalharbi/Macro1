//
//  AcheivingShortTerm.swift
//  MoneyGrow
//
//  Created by Zahrah. on 06/06/2023.
//




import UIKit
import Foundation
import SwiftUI

struct AcheivingShortTerm: View {
    @State var FixedDepost = false
    @State var ETFs = false
    @State var Stocks = false
    @State var isOptionsPresented = false
    @Environment(\.dismiss) var dismiss
    var body: some View {
        ZStack{
            NavigationView {
                VStack{
                    CloseButton(action: { dismiss() })
                    Text("Suggestions").font(.custom("Barlow SemiBold", size: 37)).foregroundColor(Color(#colorLiteral(red: 0.36, green: 0.46, blue: 0.91, alpha: 1))).multilineTextAlignment(.center)
                        .padding(.bottom,40)
                        .padding()
                    Text("The right type of investment for you\n based on your answers").font(.custom("Barlow Medium", size: 14)).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                        .padding(.top,-50)
                        .padding(.bottom,20)
                        .padding(.leading,0)
                    
                    Form {
                        Section{
                            DisclosureGroup(
                                
                                
                                isExpanded: $FixedDepost ,
                                content: {  Text("They allow investors to obtain fixed and stable returns in the near term, and are an ideal way to preserve capital.").font(.custom("Barlow Medium", size: 14)
                                ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                    
                                },
                                label: {
                                    Text("Fixed Depost")
                                        .frame(width: 328, height: 24)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                        .padding()
                                    Image(systemName: self.isOptionsPresented ? "chevron.up" : "chevron.down")
                                        .fontWeight(.medium)
                                        .foregroundColor(.gray)
                                        .padding(.leading,-40)
                                })}
                        
                        Section{
                            DisclosureGroup(
                                
                                
                                
                                isExpanded: $ETFs,
                                content: {  Text("They allow investors to invest in a variety of investment assets and achieve near-term returns, profits can be made by selling the fund when its value rises."
                                ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                    
                                },
                                label: {
                                    Text("ETFs")
                                        .frame(width: 328, height: 24)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                        .padding()
                                    Image(systemName: self.isOptionsPresented ? "chevron.up" : "chevron.down")
                                        .fontWeight(.medium)
                                        .foregroundColor(.gray)
                                        .padding(.leading,-40)
                                    
                                    
                                })}
                        
                        Section{   DisclosureGroup(
                            
                            
                            
                            isExpanded: $Stocks ,
                            content: {  Text("Investors can get high returns when the value of the stock rises, and shares can be sold in the future for near-term profits"
                            ).foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.leading)
                                
                            },
                            label: {
                                Text("Stocks")
                                
                                    .frame(width: 328, height: 24)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color(#colorLiteral(red: 0.17, green: 0.27, blue: 0.54, alpha: 1))).multilineTextAlignment(.center)
                                    .padding()
                                Image(systemName: self.isOptionsPresented ? "chevron.up" : "chevron.down")
                                    .fontWeight(.medium)
                                    .foregroundColor(.gray)
                                    .padding(.leading,-40)
                                
                            })}
                        
                    }
                    .shadow(radius:5)
                    .foregroundColor(.brown)
                    
                    .tint(Color(red: 0.166, green: 0.265, blue: 0.527))
                    .background(Color.white)
                    .padding(.top,-30)
                    .scrollContentBackground(.hidden)
                }
                
                
            }
            
      
        }
            .ignoresSafeArea(.all)
            .padding(.top,30)
        
    }
    
}
struct AcheivingShortTerm_Previews: PreviewProvider {
    static var previews: some View {
        AcheivingShortTerm()
    }
}

